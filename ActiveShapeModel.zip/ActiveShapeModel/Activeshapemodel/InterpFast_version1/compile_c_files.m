mex interp3fast_single.c image_interpolation.c
mex interp3fast_double.c image_interpolation.c
mex interp2fast_double.c image_interpolation.c
