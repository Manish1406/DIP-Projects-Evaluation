cd('functions')
mex('warp_triangle_double.c','image_interpolation.c');
mex('warp_tetrahedron_double.c','image_interpolation.c');
cd ..
